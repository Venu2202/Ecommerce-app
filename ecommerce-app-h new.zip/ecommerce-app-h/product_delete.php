<?php
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'e_store');
if(isset($_POST['delete'])){
    header("location:product_inserted.php");
    $id=$_POST['id'];
    $sql="delete from `insertproduct` where insert_id='$id'";
    $result=mysqli_query($con,$sql);
    if($result){
        echo "<script>alert('Product Deleted Successfully');</script>";
        
    }
    else{
        echo "<script>alert('Cannot Delete.Try Again Later!');</script>";
    }
}
?>