<?php
require "config/constants.php";
session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}
?>
<?php
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'e_store');
if(isset($_POST['insert'])){
	$productname= $_POST['pname'];
	$description=$_POST['description'];
	$pincode=$_POST['pincode'];
    $category=$_POST['category'];
	$image1=$_FILES['file'];
	$price=$_POST['price'];
	$area=$_POST['service'];
    $imagefilename=$image1['name'];
	$imagefileerror=$image1['error'];
	$imagefiletemp=$image1['tmp_name'];
    $filename_seperate=explode('.',$imagefilename);
	$file_extension=strtolower(end($filename_seperate));
    $extension=array('jpeg','jpg','png');
	$user_id = $_SESSION["uid"];

	if(in_array($file_extension,$extension)){
		$destinition='uploaded_images/'.$imagefilename;
		move_uploaded_file($imagefiletemp,$destinition);

        $query1="INSERT INTO `insertproduct`(`u_id`,`pname`,`prt_dec`,`pincode`,`category`,`image1`,`price`,`area`) VALUES ('$user_id','$productname','$description','$pincode','$category','$destinition','$price','$area')";
        $query_run=mysqli_query($con,$query1);

        if($query_run){
            echo "<script>alert('Data Inserted ');</script>";
        }
        else {
            echo "<script>alert('Data not Inserted ');</script>";
            echo  $con->error;
        }
	}

}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Thrift Shop</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<style>
			@media screen and (max-width:480px){
				#search{width:80%;}
				#search_btn{width:30%;float:right;margin-top:-32px;margin-right:10px;}
			}
		</style>
	</head>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only"> navigation toggle</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">Thrift Shop</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span> Product</a></li>
				<li><a href="resale.php"><span class="glyphicon glyphicon-refresh"></span> Resell</a></li>	

				<li style="width:300px;left:10px;top:10px;"><input type="text" class="form-control" id="search"></li>
				<li style="top:10px;left:30px;"><button class="btn btn-primary" id="search_btn">Search</button></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" id="cart_container" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-chat"></span> Chat <span class="badge">0</span></a>
					<div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success">
							<div class="panel-heading">
								<div class="row">
									<div class="col-md-3 col-xs-3">Sl.No</div>
									<div class="col-md-3 col-xs-3">Product Image</div>
									<div class="col-md-3 col-xs-3">Product Name</div>
									<div class="col-md-3 col-xs-3">Price in <?php echo CURRENCY; ?></div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								<!--<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in Rs.</div>
								</div>-->
								</div>
							</div>
							<div class="panel-footer"></div>
						</div>
					</div>
				</li>
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> <?php echo "Hi, ".$_SESSION["name"]; ?></a>
					<ul class="dropdown-menu">
						<li><a href="setting.php" style="text-decoration:none; color:black;">Setting</a></li>
						<li class="divider"></li>
						<li><a href="product_inserted.php" style="text-decoration:none; color:black;">Product Posted</a></li>
						<li class="divider"></li>
						<li><a href="logout.php" style="text-decoration:none; color:black;">Logout</a></li>
					</ul>
				</li>
				
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-2">
				<div id="get_category">
				</div>
				<!--<div class="nav nav-pills nav-stacked">
					<li class="active"><a href="#"><h4>Categories</h4></a></li>
					<li><a href="#">Categories</a></li>
					<li><a href="#">Categories</a></li>
					<li><a href="#">Categories</a></li>
					<li><a href="#">Categories</a></li>
				</div> -->
			</div>
			<div class="col-md-8">	
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg">
					</div>
				</div>
				<div class="panel panel-info" id="scroll">
					<div class="panel-heading">Products</div>
					<div class="panel-body">
						<div id="get_product">
						</div>
				<?php
						$query2="SELECT * FROM `insertproduct`";
						$q_run = mysqli_query($con,$query2);
						$check_product= mysqli_num_rows($q_run)>0;

					if($check_product)
					{
						while($row= mysqli_fetch_assoc($q_run))
						{
								?>
							<div class="col-md-4 mt-4">
								<div class="card">
								<img src="<?php echo $row['image1'];?>"width="150px" height="150px" alt="Product Image">
								<div class="card-body">
								<h3 class="card-title"><?php echo $row['pname']?></h3>
								<h4 class="card-title"><b>Pincode:</b><?php echo $row['pincode']?></h4>
								<h4 class="card-title"><b>Area:</b><?php echo $row['area']?></h4>
								<h4 class="card-title"><b>Price:Rs.</b><?php echo $row['price']?></h4>
								</div>
								<p class="card-text">
									<?php echo $row['prt_dec'];?>
								</p>
								<input type="submit" class="btn btn-warning" value="Contact Seller">
						
								</div>
							</div>
						<?php
						}
					}
					else
					{
						echo "No Product to display";
					}

				?>
						<!--<div class="col-md-4">
							<div class="panel panel-info">
								<div class="panel-heading">Samsung Galaxy</div>
								<div class="panel-body">
									<img src="product_images/images.JPG"/>
								</div>
								<div class="panel-heading">$.500.00
									<button style="float:right;" class="btn btn-danger btn-xs">AddToCart</button>
								</div>
							</div>
						</div> -->
					</div>
					</div>
			</div>
			<div class="col-md-1"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<center>
					<ul class="pagination" id="pageno">
						<li><a href="#">1</a></li>
					</ul>
				</center>
			</div>
		</div>
	</div>
</body>
</html>
















































