<?php
#this is Login form page , if user is already logged in then we will not allow user to access this page by executing isset($_SESSION["uid"])
#if below statment return true then we will send user to their profile.php page
if (isset($_SESSION["uid"])) {
	header("location:profile.php");
}
//in action.php page if user click on "ready to checkout" button that time we will pass data in a form from action.php page
if (isset($_POST["login_user_with_product"])) {
	//this is product list array
	$product_list = $_POST["product_id"];
	//here we are converting array into json format because array cannot be store in cookie
	$json_e = json_encode($product_list);
	//here we are creating cookie and name of cookie is product_list
	setcookie("product_list",$json_e,strtotime("+1 day"),"/","","",TRUE);

}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Thrift Shop</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
    <body>
    <div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form">
				<span class="contact100-form-title">
					Enter Details
				</span>

				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Name">
					<span class="label-input100">NAME</span>
					<input class="input100" type="text" name="name" placeholder="Enter Your Name">
				</div>

				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Address">
					<span class="label-input100">Address *</span>
					<input class="input100" type="text" name="address" placeholder="Enter Your Address">
				</div>
				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Pincode">
					<span class="label-input100">Pincode *</span>
					<input class="input100" type="number" name="pin" placeholder="Enter Your Pincode">
				</div>
				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Select Necessary Image">
					<span class="label-input100">Select image for front of outter medicine box</span>
					<input class="input100" type="file" name="outFront" placeholder="Select image">
				</div>
				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Select Necessary Image">
					<span class="label-input100">Select image for back of outter medicine box</span>
					<input class="input100" type="file" name="outBack" placeholder="Select image">
				</div>
				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Select Necessary Image">
					<span class="label-input100">Select image for front of medicine</span>
					<input class="input100" type="file" name="front" placeholder="Select image">
				</div>
				
				<div class="wrap-input100 validate-input bg1" data-validate="Please Select Necessary Image">
					<span class="label-input100">Select image for back of medicine</span>
					<input class="input100" type="file" name="back" placeholder="Select image">
				</div>

				<div class="wrap-input100 validate-input bg1 " data-validate = "Please Select Necessary Image">
					<span class="label-input100">Select image of the invoice for the medicine being sold</span>
					<input class="input100" type="file" name="invoice" placeholder="Select image">
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate = "Please Enter Expiry Date">
					<span class="label-input100">Expiry Date*</span>
					<input class="input100" type="text" name="expiry" placeholder="Enter Expiry Date">
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Area name</span>
					<div>
						<select class="js-select2" name="service">
							<option>Jayanagar</option>
							<option>Koramanagla</option>
							<option>Rajajinagar</option>
							<option>Indiranagar</option>
							<option>Marathalli</option>
							<option>Yeshwantpur</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="container-contact100-form-btn">
					<!-- onclick="location.href='./done.html';" -->
					<button class="contact100-form-btn" >
						<span>
							Submit
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
		</div>
	</div>
    </body>
	</html>


