<?php
require "config/constants.php";
session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}
?>
<?php
$con=mysqli_connect("localhost","root","","e_store");
if(isset($_POST['sold'])){
    header("location:product_inserted.php");
    $id=$_POST['id'];
	$user_id = $_SESSION["uid"];
        $query1="INSERT INTO `product_sold`(`sold_id`, `u_id`) VALUES (NULL,'$user_id')";
        $query_run=mysqli_query($con,$query1);

        if($query_run){
            echo "<script>alert('Product maked as sold.Plese delete the product ');</script>";
            $sql="delete from `insertproduct` where insert_id='$id'";
            $result=mysqli_query($con,$sql);
        }
        else {
            echo "<script>alert('Product cannot mark as sold! ');</script>";
            echo  $con->error;
        }
	}
?>
