<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Thrift Shop</title>
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="Resale/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href=Resale/Sell_med/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/vendor/noui/nouislider.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/css/util.css">
	<link rel="stylesheet" type="text/css" href="Resale/Sell_med/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form action="profile.php" class="contact100-form validate-form" method="post" enctype="multipart/form-data" >
				<span class="contact100-form-title">
					Enter Details
				</span>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Name">
					<span class="label-input100">Product Name</span>
					<input class="input100" type="text" name="pname" placeholder="Enter Your Name" required>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Description">
					<span class="label-input100">Product Description</span>
					<input class="input100" type="text" name="description" placeholder="Enter Your Description" required>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Pincode">
					<span class="label-input100">Pincode </span>
					<input class="input100" type="number" name="pincode" placeholder="Enter Your Pincode" required>
				</div>
				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Select nearest area name</span>
					<div>
						<select class="js-select2" name="service">
							<option value="Jayanagar">Jayanagar</option>
							<option value="JP nagar">JP Nagar</option>
							<option value="Basavanagudi">Basavanagudi</option>
							<option value="Yeshwanthpur">Yeshwanthpur</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Price">
					<span class="label-input100">Price </span>
					<input class="input100" type="number" name="price" placeholder="Enter Your Price" required>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Category">
					<span class="label-input100">Category </span>
					<input class="input100" type="text" name="category" placeholder="Eg:Mobile and Accessories,Home Appliance and Kitchen,Automobile parts and others" required>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="Please Select Necessary Image">
					<span class="label-input100">Select images </span>
					<input class="input100" type="file" name="file"  placeholder="Select image" required>
				</div>
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" name="insert" >
						<span>
							Submit
						</span>
						
					</button>
				</div>
			</form>
		</div>
	</div>



<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/bootstrap/js/popper.js"></script>
	<script src="Resale/Sell_med/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function(){
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});


			$(".js-select2").each(function(){
				$(this).on('select2:close', function (e){
					if($(this).val() == "Please chooses") {
						$('.js-show-service').slideUp();
					}
					else {
						$('.js-show-service').slideUp();
						$('.js-show-service').slideDown();
					}
				});
			});
		})
	</script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/daterangepicker/moment.min.js"></script>
	<script src="Resale/Sell_med/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="Resale/Sell_med/vendor/noui/nouislider.min.js"></script>
	<script>
	    var filterBar = document.getElementById('filter-bar');

	    noUiSlider.create(filterBar, {
	        start: [ 1500, 3900 ],
	        connect: true,
	        range: {
	            'min': 1500,
	            'max': 7500
	        }
	    });

	    var skipValues = [
	    document.getElementById('value-lower'),
	    document.getElementById('value-upper')
	    ];

	    filterBar.noUiSlider.on('update', function( values, handle ) {
	        skipValues[handle].innerHTML = Math.round(values[handle]);
	        $('.contact100-form-range-value input[name="from-value"]').val($('#value-lower').html());
	        $('.contact100-form-range-value input[name="to-value"]').val($('#value-upper').html());
	    });
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

</body>
</html>
