<?php
error_reporting(0);
session_start();
include "db.php";
if (!isset($_SESSION["uid"])) {
    header("Location: setting.php");
}
if (isset($_POST["submit"])) {
    $f_name = mysqli_real_escape_string($con, $_POST["f_name"]);
    $l_name = mysqli_real_escape_string($con, $_POST["l_name"]);
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $password = mysqli_real_escape_string($con, md5($_POST["password"]));
    $repassword = mysqli_real_escape_string($con, md5($_POST["repassword"]));
    $mobile = mysqli_real_escape_string($con, $_POST["mobile"]);
    $address1 = mysqli_real_escape_string($con, $_POST["address1"]);
    $address2 = mysqli_real_escape_string($con, $_POST["address2"]);
    $user_id = $_SESSION["uid"];
    if ($password === $repassword) {
        $sql = "UPDATE user_info SET first_name='$f_name',last_name='$l_name',email='$email', password='$password',mobile='$mobile',address1='$address1',address2='$address2' WHERE user_id='$_SESSION[uid]'";
            $result = mysqli_query($con, $sql);
            if ($result) {
                echo "<script>alert('Profile Updated successfully.');</script>";
            } else {
                echo "<script>alert('Profile can not Updated.');</script>";
                echo  $con->error;
            }
        
    } 
    else {
        echo "<script>alert('Password not matched. Please try again.');</script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
		<title>Thrift Shop</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>


    <link rel="stylesheet" href="style1.css">
    <title>Profile Page </title>
</head>
<body class="profile-page">
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Thrift Shop</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>

			</ul>
		</div>
	</div>
    <div class="wrapper">
        <p>Wanna logout?
            <a href="logout.php" class="text-light">Click Here</a>
        </p>
        <h1>Profile</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <?php

            $sql = "SELECT * FROM user_info WHERE user_id='$_SESSION[uid]'";
            $result = mysqli_query($con, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
                    <div class="inputBox">
                        <input type="text" id="f_name" name="f_name" placeholder="Full Name" value="<?php echo $row['first_name']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="text" id="l_name" name="l_name" placeholder="Last Name" value="<?php echo $row['last_name']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="email" id="email" name="email" placeholder="Email Address" value="<?php echo $row['email']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="password" id="password" name="password" placeholder="Password" value="<?php echo $row['password']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="password" id="repassword" name="repassword" placeholder="Confirm Password" value="<?php echo $row['password']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="text" id="mobile" name="mobile" placeholder="Mobile" value="<?php echo $row['mobile']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="text" id="address1" name="address1" placeholder="Address1" value="<?php echo $row['address1']; ?>" required>
                    </div>
                    <div class="inputBox">
                        <input type="text" id="adress2" name="address2" placeholder="Address2" value="<?php echo $row['address2']; ?>" required>
                    </div>
            <?php
                }
            }
            ?>
            <div>
                <button type="submit" name="submit" class="btn">Update Profile</button>
            </div>
        </form>
    </div>
</body>
</html>
