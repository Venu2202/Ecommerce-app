<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Thrift Shop</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css"/>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">Thrift Shop</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<style>
		img{
			width:80px;
		}
		</style>
	<h1 class="text-center my-4">
		Product Posted
	</h1>
	<div class="container mt-5">
	<?php
	session_start();
	$con=mysqli_connect("localhost","root","","e_store");
	$u_id = $_SESSION["uid"];
	$sql="SELECT * FROM `insertproduct` where `u_id`='$_SESSION[uid]'";
	$result=mysqli_query($con,$sql);
	?>
	
	<table class="table w-200">
		
    <thead class="table-dark" >
    <tr>
        <th scope="col">Product Name</th>
        <th scope="col">Product Description</th>
        <th scope="col">Pincode</th>
        <th scope="col">Area</th>
	    <th scope="col">Price</th>
	    <th scope="col">Image</th>
	    <th scope="col">Action</th>
    </tr>
    </thead>
	<?php
	while($row=mysqli_fetch_assoc($result)){
		$productname=$row['pname'];
		$productdescription=$row['prt_dec'];
		$pincode=$row['pincode'];
		$area=$row['area'];
		$price=$row['price'];
		$image=$row['image1'];

		?>
        <tbody>
			<tr>
				<td><?php echo "$productname" ?></td>
				<td><?php echo "$productdescription"?></td>
				<td><?php echo "$pincode"?></td>
				<td><?php echo "$area"?></td>
				<td><?php echo "$price"?></td>
				<td><img src="<?php echo $row['image1'];?>"width="80px" height="70px" alt="Product Image"></td>
				<form action="product_sold.php" method="post">
					<input type="hidden" name="id" value="<?php echo $row['insert_id']?>">
				<td><input type="submit" name="sold" class="btn btn-primary" value="Mark as sold"></td></form>
				<form action="product_delete.php" method="post">
					<input type="hidden" name="id" value="<?php echo $row['insert_id']?>">
				<td><input type="submit" name="delete" class="btn btn-danger" value="DELETE"></td></form>
			</tr>
		</tbody>
		<?php
	}
	?>
</table>

</div>
</body>	
</html>