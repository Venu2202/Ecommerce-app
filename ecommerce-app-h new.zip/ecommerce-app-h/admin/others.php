<?php 
session_start();  
if (!isset($_SESSION['admin_id'])) {
  header("location:login.php");
}

include "./templates/top.php"; 

?>
 
<?php include "./templates/navbar.php"; ?>
<?php
	$con=mysqli_connect("localhost","root","","e_store");
  ?>
  
<div class="container-fluid">
  <div class="row">
  <?php include "./templates/sidebar.php"; ?>
<h2>Other Details</h2>
<div class="col-xl-5 col-md-20">
  <div class="card bg-primary text-white mb-4">
    <div class="card-body" >Total User
    <?php
	$sql="SELECT * FROM `user_info`";
	$result=mysqli_query($con,$sql);
  if($product_user=mysqli_num_rows($result))
  {
    echo '<h4 class="mb-0">'.$product_user.'</h4>';
  }
  else
  {
    echo'<h4 class="mb-0">No User</h4>';
  }
	?>
    </div>
</div>
<div class="col-xl-30 col-md-20 ">
  <div class="card bg-danger text-white mb-4">
    <div class="card-body">Total Products Posted
    <?php
	$sql="SELECT * FROM `insertproduct`";
	$result=mysqli_query($con,$sql);
  if($product_total=mysqli_num_rows($result))
  {
    echo '<h4 class="mb-0">'.$product_total.'</h4>';
  }
  else
  {
    echo'<h4 class="mb-0">No Product posted</h4>';
  }
	?>
      
    </div>
</div>
<div class="col-xl-30 col-md-20  ">
  <div class="card bg-warning text-white mb-4">
    <div class="card-body">Total Amount of Products posted
    <?php
	$sql="SELECT sum(price) as `totalamount` FROM `insertproduct`";
	$result=mysqli_query($con,$sql);
  $data=mysqli_fetch_array($result);
  echo '<h4 class="mb-0">'.$data['totalamount'].'</h4>';
	?>
      
    </div>
</div>
<div class="col-xl-30 col-md-20 ">
  <div class="card bg-success text-white mb-4">
    <div class="card-body">Total Products sold
    <?php
	$sql="SELECT * FROM `product_sold`";
	$result=mysqli_query($con,$sql);
  if($product_total=mysqli_num_rows($result))
  {
    echo '<h4 class="mb-0">'.$product_total.'</h4>';
  }
  else
  {
    echo'<h4 class="mb-0">No Products sold</h4>';
  }
	?>
      
    </div>
</div>

</div>
</div>

<?php include "./templates/footer.php"; ?>

<script type="text/javascript" src="./js/admin.js"></script>
